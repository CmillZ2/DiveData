
// Colton Miller
// Lab due Wednesday April 9th
// Dr. Zoppetti
// This lab will take the data from the DiveDate file and uses the info to calculate data and text
import java.io.*;
import java.util.Scanner;

public class Diving {

	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("DiveData.txt");
		Scanner fileScanner = new Scanner(file);

			
			printIntro();
			processDives(fileScanner);
			
			fileScanner.close();
		}

	
// Prints the intro message prompt
	public static void printIntro() {
		System.out.println("Welcome to the Diver Scoring program. This program will calculate an");
		System.out.println("  overall score for a diver, based on individual dives.");
		System.out.println();
	}
// this method will grab each line from the file, also skips over the dive number
	public static void processDives(Scanner fileScanner) {
		int diveCount = 0;
		double totalScore = 0;

		while (fileScanner.hasNextLine()) {
			String line = fileScanner.nextLine();
			Scanner lineScanner = new Scanner(line);

			int diveNumber = lineScanner.nextInt(); // Grabs the dive number
			String restOfLine = line.substring(line.indexOf(" ") + 1); // skips the dive number

			double diveScore = calculateDiveScore(restOfLine); // takes the rest of the dive data and plugs it into the diveScore method

			System.out.println(
					"The diver's score for dive " + diveNumber + " is " + String.format("%.2f", diveScore) + ".");

			totalScore += diveScore;
			diveCount++;

			lineScanner.close();
		}

		if (diveCount > 0) {
			double average = totalScore / diveCount;
			System.out.println();
			System.out.println("The average score for these dives is " + String.format("%.2f", average) + ".");
		}
	}

	// Calculate one dive's score from difficulty and 7 scores
	public static double calculateDiveScore(String diveLine) {
		Scanner scanner = new Scanner(diveLine);
		double difficulty = scanner.nextDouble();
// anytime their is a sum, max or min, set them all to 0
		double sum = 0.0;
		double max = -1.0;
		double min = 11.0;

		int count = 0;
		while (scanner.hasNextDouble() && count < 7) { // reads the seven scores
			double score = scanner.nextDouble();
			sum += score;
			max = Math.max(max, score); // taking the max value from the scores
			min = Math.min(min, score); // taking the minumum value from the scores
			count++;
		}

		double validSum = sum - max - min; // drops the highest and lowest scores
		double finalScore = validSum * difficulty * 0.6; // multiply the result by the difficulty and then by 0.6

		scanner.close();
		return finalScore; // returns the final computed score
	}

}
